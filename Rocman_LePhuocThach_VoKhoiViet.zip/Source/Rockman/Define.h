#define WIDTH_SCREEN 800
#define HEIGHT_SCREEN 600

//Define depth
#define DEPTH_SCENERY 1.0f
#define DEPTH_BLOCK 0.5f
#define DEPTH_MOTION 0.0f


